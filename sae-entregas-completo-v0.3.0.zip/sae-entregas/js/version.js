// SAE Entregas · versiones. Este archivo viene en CADA actualización y se reemplaza entero.
// No hace falta tocarlo. La URL del script está en js/config.js (ese no se pisa nunca).
window.CONFIG = window.CONFIG || {};
CONFIG.VERSION_PAGINA = '0.3.0';
CONFIG.VERSION_SCRIPT_ESPERADA = '1.1.0';
if (!CONFIG.TIEMPO_ESPERA_MS) CONFIG.TIEMPO_ESPERA_MS = 60000;
if (!CONFIG.CLAVE_COPIA) CONFIG.CLAVE_COPIA = 'sae-entregas-datos-v1';
