// SAE Entregas · configuración (se completa UNA vez y no viene en las actualizaciones)
// SCRIPT_URL: la dirección que da Google al publicar apps-script/Codigo.gs como "Aplicación web" (termina en /exec).
// Las versiones están en js/version.js.
window.CONFIG = window.CONFIG || {};
CONFIG.SCRIPT_URL = '';   // ← pegar acá la URL del script
