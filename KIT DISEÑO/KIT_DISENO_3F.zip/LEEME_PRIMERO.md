# Kit de diseño 3F · cómo usarlo en el chat nuevo

1. Abrí un chat nuevo con Claude y **adjuntá este zip** (o los archivos sueltos).
2. En el primer mensaje, contale qué página es y pegá algo así:

   > Te paso el kit de diseño del equipo SAE de la Municipalidad de Tres de Febrero. Leé primero `DISENO_3F.md`
   > (cómo trabajamos, colores, letras, logos y cómo se arma una página) y `ESTANDAR_SSO_SEGURIDAD_3F.md` (entrada
   > con el Portal Educación 3F). Partí de `plantilla/`. La página nueva es: … (para qué sirve, quién la usa, qué datos
   > muestra o carga). El repo va a ser: … Antes de cambiar nada, contame cómo la armarías.

3. Pedile a **Matías** (Portal Educación 3F) que dé de alta la página en el Panel de Administrador con su dirección
   de Vercel, y que te diga el **id** que le puso: ese id va en `APP_ID` dentro de `plantilla/index.html`
   (donde dice `TU_APP_ID`). Sin eso, el Portal no deja entrar.
4. Para ver los colores y las piezas, abrí `muestra-colores.html` en el navegador (tiene botón 🌙 para el modo oscuro).
   La plantilla `index.html`, en cambio, abierta con doble clic queda **en blanco a propósito**: el guardián no muestra
   nada sin entrar por el Portal. Es lo esperado; se ve una vez publicada y dada de alta en el Portal.

Todo lo del paquete es público (no tiene claves, teléfonos ni datos personales): se puede subir a un repo público.
