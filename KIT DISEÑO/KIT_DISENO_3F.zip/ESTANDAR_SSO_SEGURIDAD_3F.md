# Estándar Oficial de Autenticación, Seguridad SSO y Alta de Proyectos — Ecosistema DGE 3F

> **Referencia única** para el **Portal Educación 3F** (`SAE3F/recurseroeducacion`, `https://portaleducacion-3f.vercel.app/`) y todas las aplicaciones satélite del ecosistema educativo de la Municipalidad de Tres de Febrero.
>
> El objetivo de este documento es evitar regresiones cuando se actualizan tableros, se ejecutan scripts generadores de HTML o se incorporan nuevos proyectos, manteniendo el estándar de ciberseguridad requerido para auditorías municipales.

---

## 1. Reglas de Oro para No Romper el SSO al Hacer Commits

1. **Nunca editar solo el `index.html` si existe un script generador:**
   - Si el proyecto genera `index.html` desde Python o desde una plantilla base (por ejemplo `build_complete_platform.py` + `Plataforma_Antropometria_3F.html`, `update_attendance.py`, `dashboard_template.html`), **modificá siempre la plantilla o el script generador** además del `index.html`.
   - Si el script usa *f-strings* de Python (`f"""..."""`), recordar escapar todas las llaves CSS/JS como `{{` y `}}`.
2. **Prohibido usar el Guardián SSO antiguo (`FNV-1a` / `secret = 'portal3f_sso_2026_secret_key'`):**
   - El Portal **ya no emite tokens FNV-1a** ni debe haber secretos hardcodeados en HTML/JS del navegador.
   - Todo tablero protegido debe validar el `?sso_token=` exclusivamente contra `POST https://portaleducacion-3f.vercel.app/api/sso-verify` (firma `HMAC-SHA256`).
3. **Respetar el timeout de 15 segundos en `/api/sso-verify`:**
   - Las funciones serverless en Vercel pueden tardar 6–10 segundos en arranque en frío (*cold start*). El `XMLHttpRequest` / `fetch` del Guardián debe usar **`timeout = 15000`** (15s), nunca menos de 10s, para evitar falsos timeouts y bucles `?returnTo=`.
4. **Priorizar sesión local vigente cuando exista:**
   - `/api/sso-verify` devuelve `exp` de **12 horas** (jornada laboral) una vez validado el ticket SSO (que dura 5 minutos en tránsito y tiene protección anti-replay por `jti` de 15 segundos).
   - Al guardar la sesión en el navegador, usar `try/catch` **separados** para `localStorage` y `sessionStorage`, para que si `localStorage` está lleno con datos de la app (por ejemplo reclamos o tablas pesadas), `sessionStorage` no falle silenciosamente.
5. **No reemplazar el bloque Guardián al subir archivos manualmente:**
   - Si un colaborador sube HTMLs desde la web de GitHub (*Add file → Upload files*), debe descargar primero la última versión de `main` para no pisar el `<head>` del Guardián SSO.

---

## 2. Guardián SSO Estándar para Aplicaciones Estáticas (HTML/JS)

Copiar este bloque al inicio de `<head>` (antes de cualquier otro `<script>` o `<link>`), reemplazando **`TU_APP_ID`** por el `id` exacto del proyecto en `data/projects.js` y `lib/resource-catalog.js`:

```html
<!-- PORTAL EDUCACIÓN 3F — GUARDIÁN SSO ESTRICTO (HMAC-SHA256 vía /api/sso-verify) -->
<style id="portal3f-guard-style">html { visibility: hidden !important; }</style>
<script>
(function() {
  var PORTAL_URL = 'https://portaleducacion-3f.vercel.app/';
  var APP_ID = 'TU_APP_ID';
  var CLAVE = 'portal3f_sso_session';
  var esArchivo = window.location.protocol === 'file:';

  function irAlPortal(extra) {
    if (esArchivo) return;
    document.documentElement.style.visibility = 'hidden';
    window.location.replace(PORTAL_URL + (extra || '?returnTo=' + encodeURIComponent(APP_ID)));
  }

  function vigente(txt) {
    try {
      var p = typeof txt === 'string' ? JSON.parse(txt) : txt;
      return (p && (!p.exp || p.exp > Date.now())) ? p : null;
    } catch(e) { return null; }
  }

  function leerGuardada() {
    var p = null;
    try { p = vigente(localStorage.getItem(CLAVE)); } catch (e) {}
    if (!p) { try { p = vigente(sessionStorage.getItem(CLAVE)); } catch (e) {} }
    return p;
  }

  function guardar(p) {
    var t = JSON.stringify(p);
    try { localStorage.setItem(CLAVE, t); } catch (e) {}
    try { sessionStorage.setItem(CLAVE, t); } catch (e) {}
  }

  function borrar() {
    try { localStorage.removeItem(CLAVE); } catch (e) {}
    try { sessionStorage.removeItem(CLAVE); } catch (e) {}
  }

  function renderBar(payload) {
    if (!payload || document.getElementById('portal-3f-sso-bar')) return;
    var bar = document.createElement('div');
    bar.id = 'portal-3f-sso-bar';
    bar.className = 'no-print';
    bar.style.cssText = 'background:#0E2A49;color:#fff;padding:6px 16px;font-family:Montserrat,sans-serif;font-size:11.5px;display:flex;align-items:center;justify-content:space-between;gap:12px;border-bottom:2px solid #F69321;z-index:99999;position:relative;flex-wrap:wrap;';
    var nombre = String(payload.nombre || payload.email || '').replace(/[&<>"']/g, function(c) { return '&#' + c.charCodeAt(0) + ';'; });
    bar.innerHTML = '<div style="display:flex;align-items:center;gap:8px;"><span style="background:#F69321;color:#0E2A49;font-weight:800;padding:1.5px 7px;border-radius:99px;font-size:10px;">SSO 3F</span><span>Conectado: <strong>' + nombre + '</strong></span></div><div style="display:flex;align-items:center;gap:10px;"><a href="' + PORTAL_URL + '" style="color:#F6BF80;font-weight:700;text-decoration:none;">⬅ Portal Educación 3F</a><button id="portal3f-logout-btn" style="background:rgba(255,255,255,0.1);color:#fecaca;border:1px solid rgba(255,255,255,0.2);border-radius:6px;padding:2px 8px;font-size:10.5px;font-weight:700;cursor:pointer;">Salir</button></div>';
    if (document.body) {
      document.body.insertBefore(bar, document.body.firstChild);
      var logoutBtn = document.getElementById('portal3f-logout-btn');
      if (logoutBtn) logoutBtn.addEventListener('click', function() { borrar(); irAlPortal('?logout=1'); });
    }
  }

  function unlock(payload) {
    window.PORTAL_3F_USER = payload;
    guardar(payload);
    try {
      var params = new URLSearchParams(window.location.search);
      if (params.has('sso_token')) {
        params.delete('sso_token');
        var q = params.toString();
        window.history.replaceState(window.history.state, document.title, window.location.pathname + (q ? '?' + q : '') + window.location.hash);
      }
    } catch(e) {}
    var guardStyle = document.getElementById('portal3f-guard-style');
    if (guardStyle) guardStyle.remove();
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function() { renderBar(payload); });
    } else {
      renderBar(payload);
    }
  }

  try {
    var saved = leerGuardada();
    if (saved) { unlock(saved); return; }

    var params = new URLSearchParams(window.location.search);
    var token = params.get('sso_token');
    if (!token) { irAlPortal(); return; }

    var xhr = new XMLHttpRequest();
    xhr.open('POST', PORTAL_URL + 'api/sso-verify', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.timeout = 15000;
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          try {
            var res = JSON.parse(xhr.responseText);
            if (res && res.valid && res.user) { unlock(res.user); return; }
          } catch(e) {}
        }
        irAlPortal();
      }
    };
    xhr.ontimeout = function() { irAlPortal(); };
    xhr.onerror = function() { irAlPortal(); };
    xhr.send(JSON.stringify({ token: token, appId: APP_ID }));
  } catch (err) {
    irAlPortal();
  }
})();
</script>
```

> **Si la app tiene pantalla de login interna propia** (como `tablero-udis` o `antropometria-3f`), además:
> 1. En `initAuth()` / `checkAuth()`, si existe `params.get('sso_token')` en la URL, hacer `return;` sin mostrar el overlay de login hasta que `unlock(payload)` lo llame cuando vuelva `/api/sso-verify`.
> 2. En `unlock(payload)`, ocultar `#login-overlay`, mostrar `#main-content` / `#dashboard-app` y llamar a `initAuth()` o `applyRoleView()`.

---

## 3. Checklist Obligatorio al Sumar una Nueva App al Portal

Cuando se incorpora un nuevo tablero o aplicación al ecosistema:

1. **En el repositorio del Portal (`SAE3F/recurseroeducacion`):**
   - [`data/projects.js`](../data/projects.js):
     - Agregar el recurso dentro de su **Área Operativa** (`dge`, `primera-infancia`, `desarrollo-educativo`, `sae`, `administrativo`, `infraestructura`).
     - Mapear su `id` en `PROJECT_PROGRAM_MAP_2027` hacia uno de los 7 Ejes del **Plan Estratégico 2027**.
   - [`lib/resource-catalog.js`](../lib/resource-catalog.js):
     - Agregar la URL en `PRIVATE_RESOURCE_URLS` y su área en `RESOURCE_AREA_BY_ID`.
     - *(Nunca dejar URLs privadas de Sheets/Drive/PowerBI expuestas en `data/projects.js`; las Apps Web de Vercel/Render sí figuran en `data/projects.js` pero requieren SSO).*
   - [`lib/portal-server.js`](../lib/portal-server.js):
     - Agregar el origen `https://...` a **`ALLOWED_SATELLITE_ORIGINS`** (CORS estricto).
     - Agregar el mapeo `'https://...': 'tu-app-id'` a **`SATELLITE_ORIGIN_TO_APP_ID`** (vinculación `Origin` ↔ `appId` anti *Cross-App Token Replay*).
   - [`portal-auth.js`](../portal-auth.js):
     - Si corresponde a todos los Jardines o UDIs por defecto, incluir el `id` en `getDefaultAppsForRole()`.
   - [`index.html`](../index.html) y [`sw.js`](../sw.js):
     - Actualizar los contadores estáticos iniciales de `index.html` y subir la versión `CACHE_NAME` de `sw.js`.
   - Mantener sincronizadas las ramas `main` y `v2-unificado`.

2. **En el repositorio de la Nueva App:**
   - Instalar el **Guardián SSO** del apartado 2 (salvo que se indique explícitamente que es pública o se habilite como pública desde el Panel de Administrador del Portal).
   - Agregar en `vercel.json` los encabezados HTTP de seguridad:
     - `X-Content-Type-Options: nosniff`
     - `X-Frame-Options: DENY` (o `SAMEORIGIN` si embebe algo propio)
     - `Referrer-Policy: strict-origin-when-cross-origin`
     - `Strict-Transport-Security: max-age=63072000; includeSubDomains; preload`
     - `Permissions-Policy: camera=(), microphone=(), geolocation=()`

---

## 4. Controles de Ciberseguridad Vigentes (Auditoría Municipal)

- **Autenticación Centralizada:** Google Identity Services validado server-side contra JWKS de Google (`/api/auth-google`) + Cookie `HttpOnly`, `Secure`, `SameSite=Lax` firmada con HMAC-SHA256 (`12h`).
- **RBAC Server-Side:** El catálogo de áreas y URLs privadas reside únicamente en el backend (`lib/resource-catalog.js` y `api/sso-token.js`). El cliente nunca define su propio `area` ni su rol.
- **Anti-Replay y Vinculación de App:** Cada token SSO dura 5 minutos, lleva `jti` único (ventana idempotente de 15s) y el servidor verifica que el `Origin` del tablero coincida con el `appId` para el cual se emitió el token.
- **Trazabilidad e IP:** Toda autenticación, acceso a tablero, alta/baja de usuario y cambio de permisos queda auditado en Supabase (`portal_audit_logs`) incluyendo dirección IP (`x-forwarded-for`).
- **Base de Datos Protegida:** `portal_users`, `portal_settings` y `portal_audit_logs` tienen `FORCE ROW LEVEL SECURITY` y políticas exclusivas para `service_role`.
- **Rate Limiting & Anti-Enumeración (Aptos para Red Municipal Compartida / NAT):** Como toda la dependencia municipal suele salir por una misma IP pública y varios dispositivos acceden en simultáneo (especialmente a SAE Gestión), los límites de `/api/sso-token` deben ser por usuario (`email + IP`), y los topes globales por IP en `/api/auth-google`, `/api/sso-verify` y `/api/request-access` deben ser amplios (60–250 req / 5–10 min), con respuestas genéricas en el formulario de solicitud de acceso.
