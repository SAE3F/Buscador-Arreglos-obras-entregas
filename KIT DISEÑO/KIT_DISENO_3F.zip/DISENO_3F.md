# Guía de diseño 3F · para páginas nuevas del equipo SAE

> Sacada de **SAE Gestión 3F** (repo `SAE3F/buscador-jardines`, versión 2.25.2, noviembre 2026), para que una página
> nueva se vea y se comporte igual. Municipalidad de Tres de Febrero · ecosistema **Portal Educación 3F**.
> Para Claude: leé todo este archivo antes de proponer o escribir código. Si algo de acá choca con lo que pida el
> equipo, preguntá.

---

## 1. Cómo trabaja el equipo (reglas que ya veníamos usando)

- **Idioma:** español rioplatense, con voseo ("tocá", "elegí", "fijate"). Textos de la página cortos, claros y sin tecnicismos.
  El equipo quiere opiniones sinceras.
- **"Para la próxima actualización" = no hacer nada todavía.** Se anota y se arranca cuando digan "hazlo", "hazlo ahora" o "arrancá".
  Si solo preguntan algo, se contesta corto, sin ponerse a programar.
- **Antes de cada actualización, revisar SIEMPRE los commits** del repo de la página **y** del Portal
  (`SAE3F/recurseroeducacion`). Partir de lo último que está en GitHub, nunca de una copia vieja. Es una orden del equipo.
- **Entregas:** un `.zip` desde la raíz del repo con solo los archivos que cambiaron, y decir qué versión tiene que
  aparecer abajo en la página y si hay que tocar Apps Script. **Nunca hacer push al repo**: lo sube el equipo.
- **El repo es público:** nada de teléfonos, mails personales, CUIT, montos, N° de factura/remito ni claves en el código.
  Los nombres de directoras de escuelas sí pueden ir (son datos institucionales).
- **Planillas de Google reales:** antes de escribir en una planilla del equipo, decir exactamente qué se va a cambiar y
  esperar el OK. No borrar nada por iniciativa propia.
- **Probar todo** antes de entregar: compu y celular, modo claro y oscuro, y que no haya scroll hacia el costado.

## 2. Portal Educación 3F (entrada con la cuenta del equipo)

Toda página protegida lleva el **guardián SSO** al principio del `<head>` (ya está en `plantilla/index.html`).
Reglas del estándar oficial (`ESTANDAR_SSO_SEGURIDAD_3F.md`, incluido en este paquete) y de `AGENTS.md`:

- Valida el `?sso_token=` contra `POST https://portaleducacion-3f.vercel.app/api/sso-verify` (HMAC-SHA256).
- **Prohibido** el guardián viejo FNV-1a o cualquier clave en texto plano.
- Tiempo de espera **15000 ms** (no menos). Primero usa la sesión guardada (12 h) con `try/catch` separados para
  `localStorage` y `sessionStorage`.
- `APP_ID`: el id que le da el Portal a la página. **Hay que pedirle a Matías** (administra el Portal) que dé de alta la
  página nueva en el Panel de Administrador con su dirección (`https://….vercel.app`); si no, el Portal no la deja entrar.
  SAE Gestión es `buscador-jardines-sae` (dominios `sae-gestion3f.vercel.app` y `buscador-jardines.vercel.app`).
- La barra azul "SSO 3F · Conectado: … · ⬅ Portal Educación 3F · Salir" la pinta el guardián: no hay que dibujarla.
- `vercel.json` con los 5 encabezados de seguridad (está en `plantilla/vercel.json`): X-Content-Type-Options,
  X-Frame-Options, Referrer-Policy, Strict-Transport-Security y Permissions-Policy. No sacarlos.
- El Portal tiene límites de pedidos por red (la oficina sale a internet con una sola dirección). Si "no deja entrar a
  ninguna app", suele ser del Portal, no de la página.

## 3. Colores (todos en `plantilla/css/tokens-3f.css`; abrí `muestra-colores.html` para verlos)

| Uso | Variable | Claro | Oscuro |
|---|---|---|---|
| Azul principal (títulos, botón principal) | `--primary` | `#163C68` | `#4d8cff` |
| Azul oscuro (hover, barra del Portal) | `--primary-hover` | `#0E2A49` | `#3a73e0` |
| Azul suave (fondos, "En gestión") | `--primary-light` | `#E0EEFF` | `#1a2a45` |
| Naranja institucional (resaltado, "3F") | `--accent` | `#F69321` | `#F69321` |
| Naranja oscuro | `--accent-hover` | `#DB7A0B` | `#DB7A0B` |
| Naranja suave (fondos, "Pendiente") | `--accent-light` | `#F6E6D4` | `#2d1f0a` |
| Verde (OK, "Resuelto") | `--success` | `#059669` | `#34d399` |
| Rojo (errores) | `--danger` | `#dc2626` | `#f87171` |
| Fondo general | `--bg-main` | `#FDFDFD` | `#0f172a` |
| Tarjetas | `--bg-card` | `#ffffff` | `#1e293b` |
| Cajitas dentro de tarjetas | `--bg-subtle` | `#F8F8F8` | `#162032` |
| Texto | `--text-primary` | `#000D1D` | `#f1f5f9` |
| Texto secundario | `--text-secondary` | `#2F4054` | `#94a3b8` |
| Texto apagado | `--text-muted` | `#B1B7BE` | `#64748b` |
| Bordes | `--border` | `#E5E5E5` | `#2d3f55` |

Barra del Portal: azul `#0E2A49`, línea y etiqueta naranja `#F69321`, enlace `#F6BF80`.

**Reglas de color:**
- El naranja es para resaltar (la palabra de color del título, avisos, "Pendiente"), no para fondos grandes.
- Siempre usar las variables, nunca colores sueltos: así el modo oscuro funciona solo.
- Cada apartado grande puede tener su tono (en SAE Gestión: "Qué se entrega hoy" verde azulado `#0f766e`,
  Calculadora azul, "Entregas, obras y arreglos" amarillento `#fffbeb` / borde `#f3d27a` / título `#8a5300`; en
  oscuro `#221d10` / `#5f4c1c` / `#fcd34d`). La flecha de achicar va del color de su apartado.
- Estados de seguimiento: **Pendiente** naranja suave, **En gestión** azul suave, **Resuelto** verde suave, **Sin estado** gris.
- Nunca el color solo para decir algo: siempre con texto o ícono al lado (✅ ⚠️ ❌ ℹ️).

## 4. Letras

- **Inter** para el texto (400, 500, 600, 700, 800). **Montserrat** para títulos y números grandes (400 a 800).
- Pedir siempre las mismas en todas las páginas (así se descargan una vez):
  `https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Montserrat:wght@400;500;600;700;800&display=swap`
- Títulos de página: Montserrat 800, `1.25rem`, azul, con una palabra en naranja: `SAE <span class="highlight">Reclamos</span>`.
- Títulos de tarjeta: `1.05–1.1rem`, 700, con un emoji al principio (📋 🛠️ 🚚 📊 📣 ⏰ 👥).
- Etiquetas en mayúsculas chicas (`.74rem`, `letter-spacing: .03em`) para encabezados de tabla y títulos de grupos.
- Números con `font-variant-numeric: tabular-nums` y separador de miles argentino (`toLocaleString('es-AR')` → 1.234).

## 5. Logos (carpeta `plantilla/assets/`)

| Archivo | Tamaño | Para qué |
|---|---|---|
| `logo_3f_96.png` | 96×96 | Logo cuadrado "3F" del encabezado (se muestra a 44×44 en compu, 26×26 en celular) |
| `logo_3f_chico.png` | 300×300 | Ícono de la pestaña del navegador (favicon) |
| `logo_3f_grande.png` / `.webp` | 600×261 / 221×96 | Logo horizontal "3F │ Municipalidad de Tres de Febrero" (encabezado del mapa, impresiones, PDF). Usar el `.webp` con el `.png` de respaldo (`<picture>`) |
| `localidades_3f.js` | 31 KB | Límites de las localidades del partido en GeoJSON (`LOCALIDADES_3F`), para mapas con Leaflet |

El logo va sobre fondo claro; en modo oscuro el cuadrado "3F" se ve bien igual (tiene su propio fondo azul).
No deformarlo ni cambiarle los colores.

## 6. Cómo se arma una página (patrones de SAE Gestión)

- **Encabezado fijo** (`.app-header`): logo 3F + título "SAE Nombre" + una línea de para qué sirve; a la derecha, los
  botones (🌙/☀️ modo oscuro, 🩺 estado, etc.). Ancho máximo del contenido: 1200–1400 px, centrado.
- **Tarjetas** (`.card`): esquinas de 16 px, borde finito, sombra muy leve; encabezado con título + subtítulo a la
  izquierda y acciones a la derecha.
- **Apartados que se achican:** botón cuadrado chico ▴/▾ arriba a la derecha del encabezado; se recuerda en la
  compu (`localStorage`). Achicado queda solo el título.
- **Listas largas:** desplegables (`<details>`) cerrados por defecto, que piden datos recién cuando se abren.
- **Pestañas:** fila de botones dentro de una franja gris; la elegida con fondo de tarjeta y sombra. Si llevan número,
  del mismo tamaño que la palabra.
- **Avisos y mensajes:** cajita con borde izquierdo de color (`.aviso`), y "toasts" abajo para confirmar acciones
  ("📥 Excel descargado"). Nada de `alert()`.
- **Botones:** principal azul relleno; secundario gris con borde; naranja solo para algo especial. Con emoji cuando
  ayuda ("⬇️ Excel", "🖨️ Imprimir", "📋 Copiar").
- **Tablas:** encabezado en mayúsculas chicas, números a la derecha, escuela en negrita.
- **Celular** (≤768 px): todo en una columna, márgenes de 16 px, botones de al menos 34–40 px de alto,
  nada de scroll hacia el costado (las tablas anchas dentro de una caja que se desliza).
- **Imprimir:** se ocultan encabezado, barra del Portal y botones (`.no-print`). En SAE Gestión hay un paso previo
  para elegir color o blanco y negro.
- **Excel:** se genera en el navegador (SAE Gestión tiene `js/excel.js`, sin librerías, con título, subtítulo, columnas y
  notas). Si la página nueva necesita Excel, se puede copiar ese archivo.

## 7. Modo oscuro

- Clase `dark` en `<html>`. Se aplica **antes de dibujar** (script chico en el `<head>`, ver plantilla) con lo que
  la persona eligió (guardado en `localStorage`) o, si nunca eligió, lo que tenga el sistema.
- Todos los colores salen de variables: en oscuro solo cambian los valores (`html.dark { --primary: … }`).
- Revisar siempre en oscuro: fondos que quedan blancos, texto gris sobre gris, bordes que desaparecen.

## 8. Datos y Google

- SAE Gestión lee y escribe planillas de Google a través de un **Apps Script** publicado como aplicación web
  (`Codigo.gs`, con `VERSION_SCRIPT`). Si la página nueva necesita planillas, conviene un script propio, con su versión,
  y que la página avise si el script quedó viejo.
- Las copias guardadas en el navegador deben saber de qué versión del script vinieron (si no, quedan datos viejos).
- Lo que se manda a la hoja va a una **cola** que reintenta sola (sin conexión, Google ocupado, pestaña trabada) y no
  duplica (cada envío lleva su número).

## 9. Archivos de este paquete

- `LEEME_PRIMERO.md` · cómo arrancar el chat nuevo.
- `DISENO_3F.md` · esta guía.
- `muestra-colores.html` · abrilo en el navegador: colores, letras, botones, estados, avisos, tabla y logos (claro y oscuro).
- `ESTANDAR_SSO_SEGURIDAD_3F.md` · estándar oficial del Portal (copia del 19/11/2026; el vigente está en
  `SAE3F/recurseroeducacion/docs/`).
- `plantilla/` · punto de partida de la página nueva:
  - `index.html` · guardián del Portal (cambiar `TU_APP_ID`), letras, modo oscuro, encabezado y una tarjeta de ejemplo.
  - `css/tokens-3f.css` · colores, letras y piezas base (tarjetas, botones, estados, avisos, campos, tablas).
  - `assets/` · logos 3F y límites de las localidades.
  - `vercel.json` · encabezados de seguridad.
  - `AGENTS.md` · reglas del ecosistema para el repo nuevo.
